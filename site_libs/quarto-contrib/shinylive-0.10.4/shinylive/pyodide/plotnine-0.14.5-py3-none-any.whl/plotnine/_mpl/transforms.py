from matplotlib.transforms import Bbox

ZEROS_BBOX = Bbox([[0, 0], [0, 0]])
